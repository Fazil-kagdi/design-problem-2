import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class JusticeLeagueTest {
	
	JusticeLeague list;
	
	@Before
	public void setup() {
		list = new JusticeLeague();
	}
	
	
	@Test
	public void testAdd() {
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		list.add(5);
		assertEquals(5,list.size());

	}

	@Test
	public void testDestroy() {
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		list.add(5);
		assertEquals(5,list.size());
		list.destroy();
		assertEquals(4,list.size());
	}

	@Test
	public void testRemove() {
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		list.add(5);
		assertEquals(5,list.size());
		list.remove();
		assertEquals(4,list.size());
	}

}
