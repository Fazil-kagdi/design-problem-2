import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.Queue;

public class JusticeLeague {
	Queue<Integer> meteors = new LinkedList<>(); 
	
	public void add(int i) {
		meteors.add(i);
	}
	
	public void destroy() {
		if(meteors.size()>0) {
			meteors.poll();
		}
		else
			throw new NoSuchElementException();
	}
	
	public void remove() {
		meteors.remove();
	}
	
	public int size() {
		return meteors.size();
	}
}
